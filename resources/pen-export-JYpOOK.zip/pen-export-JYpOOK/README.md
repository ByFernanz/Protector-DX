# SVG Procedural Grass

A Pen created on CodePen.io. Original URL: [https://codepen.io/osublake/pen/JYpOOK](https://codepen.io/osublake/pen/JYpOOK).

Remake of an old canvas favorite.