# Canvas Parallax Mountains

A Pen created on CodePen.io. Original URL: [https://codepen.io/jackrugile/pen/Apfyn](https://codepen.io/jackrugile/pen/Apfyn).

This pen is a modification of my previous [Canvas Parallax Skyline](http://codepen.io/jackrugile/pen/qLCuE) pen, only with mountains this time! This one isn't totally optimized yet though. Still having trouble finding exactly when I can reset a point to the end of the canvas, with the least runoff on the edges. Right now I am overshooting both sides a little bit too much.